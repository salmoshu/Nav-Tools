/* open-gnss-wasm: JS wrapper around the Open-GNSS RTCM3 WASM decoder.
 * Usable from browsers, web workers and Node (ESM). */
import createModule from './dist/gnss_wasm.js';
import { describeObservationSignal, nmeaSatelliteNumber } from './signals.js';

export { SYS } from './signals.js';
export const SYS_NAME = Object.freeze(['—', 'GPS', 'GLO', 'GAL', 'BDS', 'QZS', 'SBS', 'IRN']);

const KIND_EPOCH = 1;
const KIND_EPH = 2;
const KIND_STA = 3;
const KIND_NMEA = 6;
const KIND_RNXFILE = 8;
const KIND_SPP = 9;
const STATS_SIZE = 8 + 8 * 8 + 400 * 4 * 2;

let modulePromise = null;

/** Instantiate (once) and return the WASM module. */
export function initGnssWasm() {
  if (!modulePromise) modulePromise = createModule();
  return modulePromise;
}

function msgTypeFromIndex(idx) {
  if (idx >= 1 && idx <= 299) return idx + 1000;
  if (idx >= 300 && idx <= 329) return idx + 3770;
  return 0;
}

function sparseMsgMap(view, offset) {
  const map = Object.create(null);
  for (let i = 0; i < 400; i++) {
    const v = view.getUint32(offset + i * 4, true);
    if (v > 0) map[msgTypeFromIndex(i)] = v;
  }
  return map;
}

export class RtcmDecoder {
  static async create() {
    return new RtcmDecoder(await initGnssWasm());
  }

  /** @param {object} module emscripten module */
  constructor(module) {
    this.m = module;
    this.h = module._gw_create();
    if (!this.h) throw new Error('gw_create failed');
    this.inPtr = 0;
    this.inCap = 0;
    this.outPtr = 0;
    this.outCap = 0;
    this.statsPtr = module._malloc(STATS_SIZE);
    this.codePtr = module._malloc(16);
  }

  destroy() {
    if (!this.m) return;
    this.m._gw_destroy(this.h);
    this.m._free(this.statsPtr);
    this.m._free(this.codePtr);
    if (this.inPtr) this.m._free(this.inPtr);
    if (this.outPtr) this.m._free(this.outPtr);
    this.m = null;
    this.h = 0;
  }

  reset() {
    this.m._gw_reset(this.h);
  }

  startSpp({ captureTimeS = 0, scan = false, ekf = false } = {}) {
    if (this.m._gw_spp_start(this.h, captureTimeS, Number(scan), Number(ekf)) < 0)
      throw new Error('Could not initialize the RTCM3 SPP session');
  }

  captureTimeS() {
    return this.m._gw_spp_capture_time(this.h);
  }

  replaySpp() {
    if (this.m._gw_spp_replay(this.h) < 0) throw new Error('Could not start RTCM3 file replay');
  }

  pushSppNav(bytes) {
    const m = this.m;
    this._ensureIn(bytes.length);
    m.HEAPU8.set(bytes, this.inPtr);
    if (m._gw_spp_nav(this.h, this.inPtr, bytes.length) < 0)
      throw new Error('Could not read broadcast ephemeris from the RINEX NAV file');
  }

  _ensureIn(len) {
    if (len <= this.inCap) return;
    if (this.inPtr) this.m._free(this.inPtr);
    this.inCap = Math.max(len, 64 * 1024);
    this.inPtr = this.m._malloc(this.inCap);
  }

  _ensureOut(len) {
    if (len <= this.outCap) return;
    if (this.outPtr) this.m._free(this.outPtr);
    this.outCap = Math.max(len, 64 * 1024);
    this.outPtr = this.m._malloc(this.outCap);
  }

  /**
   * Push a chunk of stream bytes; returns decoded events.
   * @param {Uint8Array} bytes
   * @returns {object[]}
   */
  push(bytes) {
    const m = this.m;
    if (!m || bytes.length === 0) return [];
    this._ensureIn(bytes.length);
    new Uint8Array(m.HEAPU8.buffer, this.inPtr, bytes.length).set(bytes);
    if (m._gw_push(this.h, this.inPtr, bytes.length) < 0) throw new Error('RTCM3 decoding failed');
    return this._drain();
  }

  /** Flush the trailing epoch at end-of-stream; returns remaining events. */
  flush() {
    if (!this.m) return [];
    if (this.m._gw_flush(this.h) < 0) throw new Error('RTCM3 decoder could not flush');
    return this._drain();
  }

  /**
   * Feed one RINEX file (v2/v3/v4, obs and/or nav). Multiple files accumulate
   * (e.g. .obs + .nav); decoded epoch/eph/sta events are emitted by flush().
   * @param {Uint8Array} bytes
   */
  pushRnx(bytes) {
    const m = this.m;
    if (!m || bytes.length === 0) return;
    this._ensureIn(bytes.length);
    new Uint8Array(m.HEAPU8.buffer, this.inPtr, bytes.length).set(bytes);
    const stat = m._gw_rnx_push(this.h, this.inPtr, bytes.length);
    if (stat < 0) throw new Error(`RINEX parse failed (status ${stat})`);
  }

  _drain() {
    const m = this.m;
    const avail = m._gw_avail(this.h);
    if (avail <= 0) return [];
    this._ensureOut(avail);
    const n = m._gw_read(this.h, this.outPtr, avail);
    const view = new DataView(m.HEAPU8.buffer, this.outPtr, n);
    return parseTlv(view, n);
  }

  /** Aggregate stream statistics. */
  stats() {
    const m = this.m;
    const n = m._gw_stats(this.h, this.statsPtr, STATS_SIZE);
    if (n < STATS_SIZE) throw new Error('gw_stats failed');
    const v = new DataView(m.HEAPU8.buffer, this.statsPtr, STATS_SIZE);
    let o = 8; // skip size + reserved
    const u64 = () => { const x = v.getBigUint64(o, true); o += 8; return Number(x); };
    const s = {
      bytes: u64(),
      framesOk: u64(),
      framesCrcErr: u64(),
      nmeaLines: u64(),
      epochs: u64(),
      ephEvents: u64(),
      staEvents: u64(),
      decodeFail: u64(),
    };
    s.msgOk = sparseMsgMap(v, o);
    s.msgFail = sparseMsgMap(v, o + 400 * 4);
    return s;
  }

  /** Observation code id -> name like "1C"/"2W" (empty string if unknown). */
  codeName(code) {
    const m = this.m;
    const n = m._gw_code_name(code, this.codePtr, 16);
    if (n <= 0) return '';
    const bytes = new Uint8Array(m.HEAPU8.buffer, this.codePtr, n);
    return String.fromCharCode(...bytes);
  }

  /** Carrier frequency (Hz) for sys/code/fcn (0 if unknown). */
  codeFreq(sys, code, fcn = 0) {
    return this.m._gw_code_freq(sys, code, fcn);
  }
}

function parseTlv(view, n) {
  const events = [];
  let o = 0;
  while (o + 5 <= n) {
    const kind = view.getUint8(o);
    const len = view.getUint32(o + 1, true);
    o += 5;
    if (o + len > n) break;
    if (kind === KIND_EPOCH) events.push(parseEpoch(view, o));
    else if (kind === KIND_EPH) events.push(parseEph(view, o));
    else if (kind === KIND_STA) events.push(parseSta(view, o));
    else if (kind === KIND_NMEA) events.push(parseNmea(view, o, len));
    else if (kind === KIND_RNXFILE) events.push(parseRnxFile(view, o, len));
    else if (kind === KIND_SPP) events.push(parseSpp(view, o));
    o += len;
  }
  return events;
}

const sppTalkers = ['', 'GP', 'GL', 'GA', 'GB', 'GQ', 'GP', 'GI'];
const sppSystemIds = [0, 1, 2, 3, 4, 5, 1, 6];
const sppTextDecoder = new TextDecoder();

function nmeaSentence(fields) {
  const body = fields.join(',');
  let checksum = 0;
  for (let index = 0; index < body.length; index++) checksum ^= body.charCodeAt(index);
  return '$' + body + '*' + checksum.toString(16).toUpperCase().padStart(2, '0') + '\r\n';
}

function sppGsv(satellites) {
  const groups = new Map();
  for (const sat of satellites) {
    const talker = sppTalkers[sat.sys];
    if (!talker) continue;
    const id = String(nmeaSatelliteNumber(sat.sys, sat.prn)).padStart(2, '0');
    const angles = sat.positionKnown && sat.elevation >= 0;
    const elevation = angles ? String(Math.round(sat.elevation)).padStart(2, '0') : '';
    const azimuth = angles ? String((Math.round(sat.azimuth) + 360) % 360).padStart(3, '0') : '';
    const signals = sat.signals.length ? sat.signals : [{ signalId: '0', snr: 0 }];
    for (const { signalId, snr } of signals) {
      const key = `${talker}:${signalId}`;
      if (!groups.has(key)) groups.set(key, { talker, signalId, satellites: new Map() });
      const group = groups.get(key).satellites;
      // Several observation codes can share a standardized NMEA signal ID.
      if (!group.has(id) || snr > group.get(id).snr) group.set(id, { id, elevation, azimuth, snr });
    }
  }
  let nmea = '';
  for (const { talker, signalId, satellites: group } of groups.values()) {
    const satellites = [...group.values()];
    const messages = Math.ceil(satellites.length / 4);
    for (let index = 0; index < messages; index++) {
      const fields = satellites.slice(index * 4, (index + 1) * 4).flatMap(({ id, elevation, azimuth, snr }) => [
        id, elevation, azimuth, snr > 0 ? String(Math.round(snr)).padStart(2, '0') : '',
      ]);
      nmea += nmeaSentence([talker + 'GSV', messages, index + 1, satellites.length, ...fields, signalId]);
    }
  }
  return nmea;
}

function sppNmea(timeS, valid, satellites, dop, positionText) {
  const iso = new Date(Math.round(timeS * 1000)).toISOString();
  const time = iso.slice(11, 23).replace(/:/g, '');
  const date = iso.slice(8, 10) + iso.slice(5, 7) + iso.slice(2, 4);
  const used = new Map();
  for (const sat of satellites) {
    const system = sppSystemIds[sat.sys];
    if (!system) continue;
    if (!used.has(system)) used.set(system, []);
    if (sat.used) used.get(system).push(String(nmeaSatelliteNumber(sat.sys, sat.prn)).padStart(2, '0'));
  }
  let nmea = sppGsv(satellites);
  const dopFields = dop.map((value) => value > 0 && Number.isFinite(value) ? value.toFixed(1) : '');
  for (const [system, satellites] of used) {
    for (let offset = 0; offset < Math.max(1, satellites.length); offset += 12) {
      const ids = satellites.slice(offset, offset + 12);
      while (ids.length < 12) ids.push('');
      nmea += nmeaSentence(['GNGSA', 'A', valid ? 3 : 1, ...ids, ...dopFields, system]);
    }
  }
  const [gga, rmc] = positionText.trim().split(/\r?\n/).map((line) => line.slice(1).split('*')[0].split(','));
  gga[1] = time;
  if (!valid) { gga[6] = '0'; gga[7] = '00'; }
  gga[8] = dopFields[1];
  rmc[1] = time;
  rmc[9] = date;
  if (!valid) { rmc[2] = 'V'; rmc[12] = 'N'; }
  return nmea + nmeaSentence(rmc) + nmeaSentence(gga);
}

function parseSpp(view, offset) {
  const timeS = view.getFloat64(offset, true);
  const quality = view.getUint8(offset + 8);
  const satelliteCount = view.getUint16(offset + 9, true);
  const textLength = view.getUint16(offset + 11, true);
  const dop = [13, 17, 21].map((field) => view.getFloat32(offset + field, true));
  const satellites = [];
  let position = offset + 25;
  for (let index = 0; index < satelliteCount; index++) {
    const sys = view.getUint8(position);
    const satellite = {
      sys,
      prn: view.getUint8(position + 1),
      used: view.getUint8(position + 2) !== 0,
      positionKnown: view.getUint8(position + 3) !== 0,
      azimuth: view.getFloat32(position + 4, true),
      elevation: view.getFloat32(position + 8, true),
      signals: [],
    };
    const signalCount = view.getUint8(position + 12);
    position += 13;
    for (let slot = 0; slot < signalCount; slot++, position += 8) {
      const first = view.getUint8(position);
      if (!first) continue;
      const code = String.fromCharCode(first, view.getUint8(position + 1));
      satellite.signals.push({
        ...describeObservationSignal(sys, code),
        code,
        snr: view.getUint16(position + 2, true) / 1000,
        frequencyHz: view.getUint32(position + 4, true),
      });
    }
    satellites.push(satellite);
  }
  const text = sppTextDecoder.decode(new Uint8Array(view.buffer, view.byteOffset + position, textLength));
  const status = quality === 1 ? 'fix' : quality === 2 ? 'waiting-ephemeris' : 'no-fix';
  return { kind: 'spp', timeS, status, satellites, nmea: sppNmea(timeS, quality === 1, satellites, dop, text) };
}

function parseEpoch(view, o) {
  const timeS = view.getFloat64(o, true);
  const nsat = view.getUint16(o + 8, true);
  const flag = view.getUint8(o + 10);
  let p = o + 12;
  const sats = new Array(nsat);
  for (let i = 0; i < nsat; i++) {
    const sat = view.getUint16(p, true);
    const sys = view.getUint8(p + 2);
    const prn = view.getUint8(p + 3);
    const fcn = view.getInt8(p + 4);
    p += 6;
    const obs = new Array(3);
    for (let j = 0; j < 3; j++) {
      obs[j] = {
        code: view.getUint8(p),
        lli: view.getUint8(p + 1),
        snr: view.getUint16(p + 2, true) * 0.001,
        d: view.getFloat32(p + 4, true),
        p: view.getFloat64(p + 8, true),
        l: view.getFloat64(p + 16, true),
      };
      p += 24;
    }
    sats[i] = { sat, sys, prn, fcn, obs };
  }
  return { kind: 'epoch', timeS, flag, sats };
}

function parseEph(view, o) {
  return {
    kind: 'eph',
    msgType: view.getUint16(o, true),
    sys: view.getUint8(o + 2),
    isGlo: view.getUint8(o + 3) !== 0,
    sat: view.getUint16(o + 4, true),
    prn: view.getUint8(o + 6),
    iode: view.getInt32(o + 8, true),
    iodc: view.getInt32(o + 12, true),
    week: view.getInt32(o + 16, true),
    toeS: view.getFloat64(o + 20, true),
    tocS: view.getFloat64(o + 28, true),
    recvS: view.getFloat64(o + 36, true),
    fitH: view.getFloat64(o + 44, true),
    f0: view.getFloat32(o + 52, true),
    f1: view.getFloat32(o + 56, true),
  };
}

function parseSta(view, o) {
  return {
    kind: 'sta',
    msgType: view.getUint16(o, true),
    staid: view.getUint32(o + 4, true),
    pos: [
      view.getFloat64(o + 8, true),
      view.getFloat64(o + 16, true),
      view.getFloat64(o + 24, true),
    ],
    hgt: view.getFloat64(o + 32, true),
    del: [
      view.getFloat64(o + 40, true),
      view.getFloat64(o + 48, true),
      view.getFloat64(o + 56, true),
    ],
  };
}

function parseNmea(view, o, len) {
  const bytes = new Uint8Array(view.buffer, view.byteOffset + o, len);
  let text = '';
  for (let i = 0; i < len; i++) text += String.fromCharCode(bytes[i]);
  return { kind: 'nmea', text };
}

function parseRnxFile(view, o, len) {
  const nameLen = view.getUint8(o);
  const nameBytes = new Uint8Array(view.buffer, view.byteOffset + o + 1, nameLen);
  let name = '';
  for (let i = 0; i < nameLen; i++) name += String.fromCharCode(nameBytes[i]);
  const dataLen = view.getUint32(o + 1 + nameLen, true);
  const start = o + 1 + nameLen + 4;
  const data = new Uint8Array(view.buffer, view.byteOffset + start, dataLen).slice();
  return { kind: 'rnxfile', name, data };
}

/**
 * Convert an RTCM3 byte stream to a RINEX file set (obs + nav, RINEX 3.04).
 * @param {Uint8Array} bytes RTCM3 stream
 * @param {string} [base='output'] output file base name (replaces 'gw_out')
 * @returns {Promise<{name: string, data: Uint8Array}[]>}
 */
export async function rtcm2rnx(bytes, base = 'output') {
  const m = await initGnssWasm();
  const h = m._gw_create();
  if (!h) throw new Error('gw_create failed');
  const inPtr = m._malloc(bytes.length);
  try {
    new Uint8Array(m.HEAPU8.buffer, inPtr, bytes.length).set(bytes);
    const n = m._gw_rtcm2rnx(h, inPtr, bytes.length);
    if (n < 0) throw new Error(`RTCM->RINEX conversion failed (status ${n})`);
    const avail = m._gw_avail(h);
    if (avail <= 0) return [];
    const outPtr = m._malloc(avail);
    try {
      const read = m._gw_read(h, outPtr, avail);
      const view = new DataView(m.HEAPU8.buffer, outPtr, read);
      return parseTlv(view, read)
        .filter((e) => e.kind === 'rnxfile')
        .map((e) => ({ name: e.name.replace(/^gw_out\./, `${base}.`), data: e.data }));
    } finally {
      m._free(outPtr);
    }
  } finally {
    m._free(inPtr);
    m._gw_destroy(h);
  }
}

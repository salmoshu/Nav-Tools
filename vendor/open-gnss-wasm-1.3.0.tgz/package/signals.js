export const SYS = Object.freeze({
  NONE: 0, GPS: 1, GLO: 2, GAL: 3, BDS: 4, QZS: 5, SBS: 6, IRN: 7,
});

// NMEA 4.11 signal identifiers, keyed by constellation. The observation codes
// are the RINEX labels returned by Open-GNSS code2obs().
const signalDefinitions = {
  [SYS.GPS]: {
    1: ['L1', 'L1 C/A', '1C'], 2: ['L1', 'L1 P(Y)', '1P 1W 1Y'], 3: ['L1', 'L1 M', '1M'],
    4: ['L2', 'L2 P(Y)', '2P 2W 2Y'], 5: ['L2', 'L2C-M', '2S'], 6: ['L2', 'L2C-L', '2L'],
    7: ['L5', 'L5 I', '5I'], 8: ['L5', 'L5 Q', '5Q'],
  },
  [SYS.GLO]: {
    1: ['G1', 'G1 C/A', '1C'], 2: ['G1', 'G1 P', '1P'],
    3: ['G2', 'G2 C/A', '2C'], 4: ['G2', 'G2 P', '2P'],
  },
  [SYS.GAL]: {
    1: ['E5a', 'E5a', '5I 5Q 5X'], 2: ['E5b', 'E5b', '7I 7Q 7X'],
    3: ['E5a+b', 'E5a+b', '8I 8Q 8X'], 4: ['E6', 'E6 A', '6A'],
    5: ['E6', 'E6 B/C', '6B 6C 6X'], 6: ['E1', 'E1 A', '1A'], 7: ['E1', 'E1 B/C', '1B 1C 1X'],
  },
  [SYS.BDS]: {
    1: ['B1I', 'B1I', '2I'], 2: ['B1I', 'B1Q', '2Q'], 3: ['B1C', 'B1C', '1D 1P 1X'],
    4: ['B1A', 'B1A', '1A'], 5: ['B2a', 'B2a', '5D 5P 5X'], 6: ['B2b', 'B2b', '7D 7P 7Z'],
    7: ['B2a+b', 'B2a+b', '8D 8P 8X'], 8: ['B3', 'B3I', '6I'], 9: ['B3', 'B3Q', '6Q'],
    A: ['B3', 'B3A', '6A'], B: ['B2I', 'B2I', '7I'], C: ['B2I', 'B2Q', '7Q'],
  },
  [SYS.QZS]: {
    1: ['L1', 'L1 C/A', '1C'], 2: ['L1', 'L1C-D', '1S'], 3: ['L1', 'L1C-P', '1L'],
    4: ['L1', 'L1S', '1Z'], 5: ['L2', 'L2C-M', '2S'], 6: ['L2', 'L2C-L', '2L'],
    7: ['L5', 'L5 I', '5I'], 8: ['L5', 'L5 Q', '5Q'], 9: ['L6', 'L6D', '6S'], A: ['L6', 'L6E', '6E'],
  },
  [SYS.SBS]: {
    1: ['L1', 'L1 C/A', '1C'], 7: ['L5', 'L5 I', '5I'], 8: ['L5', 'L5 Q', '5Q'],
  },
  [SYS.IRN]: {
    1: ['L5', 'L5 SPS', '5A'], 2: ['S', 'S SPS', '9A'], 3: ['L5', 'L5 RS', '5B 5C 5X'],
    4: ['S', 'S RS', '9B 9C 9X'], 5: ['L1', 'L1 SPS', '1D 1P 1X'],
  },
};

const observationBands = {
  [SYS.GPS]: { 1: 'L1', 2: 'L2', 5: 'L5' },
  [SYS.GLO]: { 1: 'G1', 2: 'G2', 3: 'G3', 4: 'G1a', 6: 'G2a' },
  [SYS.GAL]: { 1: 'E1', 5: 'E5a', 6: 'E6', 7: 'E5b', 8: 'E5a+b' },
  [SYS.BDS]: { 1: 'B1', 2: 'B1I', 5: 'B2a', 6: 'B3', 7: 'B2', 8: 'B2a+b' },
  [SYS.QZS]: { 1: 'L1', 2: 'L2', 5: 'L5', 6: 'L6' },
  [SYS.SBS]: { 1: 'L1', 5: 'L5' },
  [SYS.IRN]: { 1: 'L1', 5: 'L5', 9: 'S' },
};

const byNmea = new Map();
const byCode = new Map();
for (const [sys, entries] of Object.entries(signalDefinitions)) {
  for (const [signalId, [band, label, codes]] of Object.entries(entries)) {
    const description = Object.freeze({ band, label, signalId });
    byNmea.set(`${sys}:${signalId}`, description);
    for (const code of codes.split(' ')) byCode.set(`${sys}:${code}`, description);
  }
}

export function describeNmeaSignal(sys, signalId) {
  return byNmea.get(`${sys}:${signalId.trim().toUpperCase()}`);
}

export function describeObservationSignal(sys, code) {
  const description = byCode.get(`${sys}:${code}`);
  if (description) return description;
  const band = observationBands[sys]?.[code[0]];
  return { band, label: band ? `${band} (${code})` : code, signalId: '0' };
}

export function nmeaSatelliteNumber(sys, prn) {
  if (sys === SYS.GLO) return prn + 64;
  if (sys === SYS.QZS) return prn - 192;
  if (sys === SYS.SBS) return prn - 87;
  return prn;
}

export declare const SYS: Readonly<{
  NONE: 0; GPS: 1; GLO: 2; GAL: 3; BDS: 4; QZS: 5; SBS: 6; IRN: 7;
}>;

export interface SignalDescription {
  readonly band?: string;
  readonly label: string;
  readonly signalId: string;
}

export declare function describeNmeaSignal(sys: number, signalId: string): SignalDescription | undefined;
export declare function describeObservationSignal(sys: number, code: string): SignalDescription;
export declare function nmeaSatelliteNumber(sys: number, prn: number): number;

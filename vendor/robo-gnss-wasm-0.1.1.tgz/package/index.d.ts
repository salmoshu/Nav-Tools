/* robo-gnss-wasm type declarations */

export declare const SYS: Readonly<{
  NONE: 0; GPS: 1; GLO: 2; GAL: 3; BDS: 4; QZS: 5; SBS: 6; IRN: 7;
}>;
export declare const SYS_NAME: readonly string[];

export interface FreqObs {
  /** observation code id (0 = none); name via RtcmDecoder.codeName() */
  code: number;
  /** loss of lock indicator */
  lli: number;
  /** signal strength (dBHz, 0 = none) */
  snr: number;
  /** doppler (Hz) */
  d: number;
  /** pseudorange (m, 0 = none) */
  p: number;
  /** carrier-phase (cycles, 0 = none) */
  l: number;
}

export interface EpochSat {
  /** RTKLIB internal satellite number (stable identity) */
  sat: number;
  /** SYS_* id (1=GPS 2=GLO 3=GAL 4=BDS 5=QZS 6=SBS 7=IRN) */
  sys: number;
  prn: number;
  /** GLONASS frequency channel (-7..+6, -8 = unknown, 0 = n/a) */
  fcn: number;
  /** up to 3 frequency slots */
  obs: FreqObs[];
}

export interface EpochEvent {
  kind: 'epoch';
  /** unix seconds (UTC) */
  timeS: number;
  /** epoch flag (0 = ok) */
  flag: number;
  sats: EpochSat[];
}

export interface EphEvent {
  kind: 'eph';
  msgType: number;
  sys: number;
  isGlo: boolean;
  sat: number;
  prn: number;
  iode: number;
  iodc: number;
  week: number;
  /** unix seconds */
  toeS: number;
  tocS: number;
  /** stream time when received (unix seconds, 0 = unknown) */
  recvS: number;
  /** fit interval (h); GLONASS: age of operation */
  fitH: number;
  /** clock bias: af0 (s) / GLONASS taun */
  f0: number;
  /** clock drift: af1 (s/s) / GLONASS gamn */
  f1: number;
}

export interface StaEvent {
  kind: 'sta';
  msgType: number;
  staid: number;
  /** ECEF position (m) */
  pos: [number, number, number];
  hgt: number;
  /** antenna delta (e/n/u or x/y/z) */
  del: [number, number, number];
}

export interface NmeaEvent {
  kind: 'nmea';
  text: string;
}

export interface RnxFileEvent {
  kind: 'rnxfile';
  name: string;
  data: Uint8Array;
}

export type GnssEvent = EpochEvent | EphEvent | StaEvent | NmeaEvent;

export interface GnssStreamStats {
  bytes: number;
  framesOk: number;
  framesCrcErr: number;
  nmeaLines: number;
  epochs: number;
  ephEvents: number;
  staEvents: number;
  /** CRC-valid frames whose decode failed (e.g. GLO string failures) */
  decodeFail: number;
  /** sparse map: RTCM message type -> decoded frame count */
  msgOk: Record<number, number>;
  /** sparse map: RTCM message type -> failed frame count */
  msgFail: Record<number, number>;
}

export declare function initGnssWasm(): Promise<unknown>;

export declare class RtcmDecoder {
  static create(): Promise<RtcmDecoder>;
  destroy(): void;
  reset(): void;
  push(bytes: Uint8Array): GnssEvent[];
  flush(): GnssEvent[];
  /**
   * Feed one RINEX file (v2/v3/v4, obs and/or nav). Multiple files accumulate;
   * decoded events are emitted by flush().
   */
  pushRnx(bytes: Uint8Array): void;
  stats(): GnssStreamStats;
  codeName(code: number): string;
  /** carrier frequency (Hz) for sys/code/fcn (0 if unknown) */
  codeFreq(sys: number, code: number, fcn?: number): number;
}

/** Convert an RTCM3 byte stream to a RINEX file set (obs + nav, RINEX 3.04). */
export declare function rtcm2rnx(
  bytes: Uint8Array,
  base?: string,
): Promise<{ name: string; data: Uint8Array }[]>;

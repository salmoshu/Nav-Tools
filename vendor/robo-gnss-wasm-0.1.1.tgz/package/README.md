# robo-gnss-wasm

Robo-GNSS（rtklibexplorer/RTKLIB demo5 分支）的 RTCM3/RINEX 解码器，经 Emscripten 编译为
WebAssembly，供 Nav-Tools 等 JS/TS 宿主直接调用。支持 RTCM3 与 NMEA 混合流
（如 AG3335A 模组的混合输出）、RINEX 2/3 观测与星历文件，以及 RTCM3 → RINEX 3.04 转换
（内置 RTKLIB convrnx 引擎）。

## 构建

需要 emsdk（`emcc` 在 PATH 上）：

```bash
node build.mjs        # 产出 dist/gnss_wasm.js（ESM + 内联 wasm，单文件）
node test/smoke.mjs   # Node 烟雾测试（解码真实 RTCM 采样并断言统计）
```

注意两点：

- **必须带星座开关宏**（build.mjs 已内置）：`-DENAGLO -DENAQZS -DENAGAL -DENACMP
  -DENAIRN`，与根目录 `RTKLib.pri` 对齐。缺少这些宏时 `MINPRNxxx/MAXPRNxxx`
  折叠为 0，`satno()` 会拒绝所有非 GPS 卫星（表现为 1020/1042/1046 等星历帧
  100% 译码失败、GLO/GAL/BDS 观测全部丢失）。
- 调试：`GW_CFLAGS="-DGW_DEBUG" node build.mjs` 会在译码失败时向 stderr
  打印帧类型/长度/PRN。

## 宿主接入（Nav-Tools）

Nav-Tools 以 `file:` tarball 依赖引用本包的构建产物（`vendor/robo-gnss-wasm-x.y.z.tgz`，
已随 Nav-Tools 仓库提交，保证 CI 自包含安装）。本仓库重新构建 `dist/` 后，需在
Nav-Tools 根目录执行同步脚本刷新 tarball 并重装：

```bash
bash scripts/sync-robo-gnss-wasm.sh   # pnpm pack → vendor/*.tgz
pnpm install                          # 同步 lockfile 与 node_modules
```

## 用法

```ts
import { RtcmDecoder, rtcm2rnx } from 'robo-gnss-wasm';

const dec = await RtcmDecoder.create();
for (const chunk of streamChunks) {
  for (const ev of dec.push(chunk)) {
    // ev.kind: 'epoch' | 'eph' | 'sta' | 'nmea'
  }
}
dec.push(tail); dec.flush();
const stats = dec.stats();        // 帧/类型/错误统计
dec.codeName(code);               // 观测码 id -> "1C"/"2W"
dec.codeFreq(sys, code, fcn);     // 载波频率 Hz（GF 组合、波长换算用）
dec.destroy();

// RINEX 文件（obs/nav 可多文件合并，与 RTCM 路径产出同一套事件）：
const rnx = await RtcmDecoder.create();
rnx.pushRnx(obsBytes);
rnx.pushRnx(navBytes);
for (const ev of rnx.flush()) { /* epoch/eph/sta 事件 */ }
rnx.destroy();

// RTCM3 → RINEX 3.04（convrnx 引擎，返回 obs+各系统 nav 文件）：
const files = await rtcm2rnx(rtcmBytes, 'base_name');
// files: [{ name: 'base_name.obs', data: Uint8Array }, { name: 'base_name.nav', ... }, ...]
```

## 结构

- `gnss_wasm.c` — C 桥接层：并行帧扫描统计（`input_rtcm3` 对 CRC 错误静默），
  历元按时间合并 flush（同历元多系统 MSM 帧合并为一条 EPOCH 事件），
  输出 TLV 二进制事件供 JS 零拷贝解析。RINEX 经 `gw_rnx_push` 走 `readrnx`
  累积（多文件合并），flush 时统一排序去重后产出同一套 TLV 事件；
  `gw_rtcm2rnx` 在 MEMFS 内调用 convrnx（RINEX 3.04、七系统、全频点全观测码），
  生成的 obs/nav 文件以 RNXFILE TLV 回传。
- `index.js` / `index.d.ts` — ESM 封装与类型。
- `test/smoke.mjs` — 真实数据冒烟断言（RTCM 解码 + rtcm2rnx 往返一致性）。
